<?php
/**
 * Content wrappers - start
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Filtered CSS classes
 * ------
 * section: grid-wrap gw-woocommerce
 * div: grid-container gc-woocommerce grid-1 padding-small clearfix
 * ------
 */
?>
<section id="content" class="section_woocomerce">
	<div class="container">
